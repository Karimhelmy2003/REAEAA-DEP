USE REAEAA_DEPI_DB;

INSERT INTO Appointments_REAEAA_DEPI (Date, Time, DoctorID, PatientID, AdminID)
VALUES ('2025-05-08', '10:30', 1, 1, 1);  -- Use a real DoctorID from the query above

