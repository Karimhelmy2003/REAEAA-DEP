﻿namespace REAEAA_DEPI_API.DTOs
{
    public class LoginResponseDTO
    {
        public string Token { get; set; }
        public string Role { get; set; }
    }
}
